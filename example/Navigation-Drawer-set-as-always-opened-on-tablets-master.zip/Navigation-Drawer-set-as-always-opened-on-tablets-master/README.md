# Navigation-Drawer-set-as-always-opened-on-tablets

this is just a prove of concept for [this stackoverflow question] (http://stackoverflow.com/questions/17133541/navigation-drawer-set-as-always-opened-on-tablets)

based on @methodin sample code and @CommonsWare Answer

don't take a look if you're just passing (it's a shitty code, was in a hurry :D)
